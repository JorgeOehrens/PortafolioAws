from django.contrib import admin
from .models import Proyectos, Profesional, Experiencia
# Register your models here.
admin.site.register(Proyectos)
admin.site.register(Profesional)
admin.site.register(Experiencia)
